import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { AvailableLoadsComponent } from './available-loads/available-loads.component';
import { FindLoadsComponent } from './find-loads/find-loads.component';
import { TripPlannerComponent } from './trip-planner/trip-planner.component';
import { ReferralsComponent } from './referrals/referrals.component';
import { LoyaltyPointsComponent } from './loyalty-points/loyalty-points.component';
import { MyProfileComponent } from './my-profile/my-profile.component';

@NgModule({
  declarations: [
    AppComponent,
    DashBoardComponent,
    AvailableLoadsComponent,
    FindLoadsComponent,
    TripPlannerComponent,
    ReferralsComponent,
    LoyaltyPointsComponent,
    MyProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
