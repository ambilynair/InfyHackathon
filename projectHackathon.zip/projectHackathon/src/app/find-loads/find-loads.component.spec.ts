import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FindLoadsComponent } from './find-loads.component';

describe('FindLoadsComponent', () => {
  let component: FindLoadsComponent;
  let fixture: ComponentFixture<FindLoadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FindLoadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FindLoadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
