import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-find-loads',
  templateUrl: './find-loads.component.html',
  styleUrls: ['./find-loads.component.css']
})
export class FindLoadsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
