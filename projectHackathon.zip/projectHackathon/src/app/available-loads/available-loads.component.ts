import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-available-loads',
  templateUrl: './available-loads.component.html',
  styleUrls: ['./available-loads.component.css']
})
export class AvailableLoadsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
